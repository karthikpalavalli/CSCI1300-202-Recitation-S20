#include<iostream>
#include<iomanip>

using namespace std;

int main(){
    cout<<"This is CSCI 1300"<<endl;

    float x = 0.32567;

    cout << fixed << setprecision(2) << x << endl;
    
    return 0;
}
